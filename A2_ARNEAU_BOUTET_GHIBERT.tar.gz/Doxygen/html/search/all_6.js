var searchData=
[
  ['new_5fgame',['new_game',['../game_8h.html#af3b2914d6023cc0bcd449dbb633182b1',1,'game.c']]],
  ['new_5fgame_5fhr',['new_game_hr',['../game_8h.html#af940f80ca2e7ea78c671bacac5faf5fd',1,'game.c']]],
  ['new_5fpiece',['new_piece',['../piece_8h.html#a470320e8f11946183157f8896017e05b',1,'piece.c']]],
  ['new_5fpiece_5frh',['new_piece_rh',['../piece_8h.html#a46796f1969567e7570b8e7d01c494fac',1,'piece.c']]]
];
