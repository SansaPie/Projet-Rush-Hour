var searchData=
[
  ['can_5fmove_5fx',['can_move_x',['../piece_8h.html#a00b21827350e45b5882ca84d0872965e',1,'piece.c']]],
  ['can_5fmove_5fy',['can_move_y',['../piece_8h.html#aa24e06971b387dfffce83ada0344601b',1,'piece.c']]],
  ['copy_5fgame',['copy_game',['../game_8h.html#a8e05e660605fad74be567a36a6775c6d',1,'game.c']]],
  ['copy_5fpiece',['copy_piece',['../piece_8h.html#ada8ffd416b6b6040756fb0de9edf2d94',1,'piece.c']]]
];
