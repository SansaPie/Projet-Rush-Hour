var searchData=
[
  ['delete_5fgame',['delete_game',['../game_8h.html#a46eb61834d6cd2ff48d3c0ddaa2d9e91',1,'game.c']]],
  ['delete_5fpiece',['delete_piece',['../piece_8h.html#adc8fbb6db6b4d8476913bea8b147d3fb',1,'piece.c']]]
];
