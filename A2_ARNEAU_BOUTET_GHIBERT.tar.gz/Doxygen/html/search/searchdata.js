var indexSectionsWithContent =
{
  0: "cdfgimnpt",
  1: "fgmpt",
  2: "gp",
  3: "cdgimnp",
  4: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "enums"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Enumerations"
};

