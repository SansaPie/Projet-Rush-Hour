Ce code est l'implémentation d'un jeu puzzle de type âne rouge ou rush hour. 
Vous êtes actuellement en présence de la seconde version du code. 

La compilation se fait à l'aide d'un CMake. Les fichiers de configurations de jeu sont les suivants :
	easy_rh_1.txt
	easy_rh_2.txt
	normal_rh_1.txt
	normal_rh_2.txt
	difficult_rh_1.txt
	difficult_rh_2.txt
	easy_ar_1.txt
	normal_ar_1.txt
	difficult_ar_1.txt
	difficult_ar_2.txt

Placez-vous dans le fichier build, puis lancez la commande make dans votre terminal. Ensuite, lancez l'exécutable en tapant ./main
Le jeu va s'afficher dans le terminal avec les règles du jeu. 
Avant de commencer, vous devrez choisir une configuration de jeu. La liste des fichiers contenant les différentes configurations s'affichera dans le terminal. Faîtes votre choix, et recopiez le nom entier du fichier choisi. Le jeu va ensuite se lancer. 
